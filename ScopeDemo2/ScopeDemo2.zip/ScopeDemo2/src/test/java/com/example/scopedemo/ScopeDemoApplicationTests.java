package com.example.scopedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScopeDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
